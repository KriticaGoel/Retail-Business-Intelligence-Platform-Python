# Retail BI Platform — Day 1 Dataset

Synthetic retail transaction dataset for learning and portfolio development.
All records are fictional.

## Files
- customers.csv: one row per customer
- products.csv: one row per product
- orders.csv: one row per order
- order_items.csv: one row per product line within an order

## Relationships
- customers.customer_id -> orders.customer_id
- orders.order_id -> order_items.order_id
- products.product_id -> order_items.product_id

## Important
- Revenue should generally be calculated from order_items, not by summing product prices in orders.
- Decide and document how Returned and Cancelled orders should be treated in each KPI.
- unit_cost is a fraction of unit_price, not a currency amount. Estimated line cost = unit_price * unit_cost * quantity.
- discount_pct is a decimal fraction (e.g. 0.10 means 10%).
- This is synthetic data and should not be presented as real company performance.
